/*

File: NaiveFormat.c, part of ExampleIPBCodec

Abstract: Utilities for management of planar YUV 4:2:0 buffers, common to the naive encoder and decoder.

Version: 1.0

� Copyright 2005 Apple Computer, Inc. All rights reserved.

IMPORTANT:  This Apple software is supplied to 
you by Apple Computer, Inc. ("Apple") in 
consideration of your agreement to the following 
terms, and your use, installation, modification 
or redistribution of this Apple software 
constitutes acceptance of these terms.  If you do 
not agree with these terms, please do not use, 
install, modify or redistribute this Apple 
software.

In consideration of your agreement to abide by 
the following terms, and subject to these terms, 
Apple grants you a personal, non-exclusive 
license, under Apple's copyrights in this 
original Apple software (the "Apple Software"), 
to use, reproduce, modify and redistribute the 
Apple Software, with or without modifications, in 
source and/or binary forms; provided that if you 
redistribute the Apple Software in its entirety 
and without modifications, you must retain this 
notice and the following text and disclaimers in 
all such redistributions of the Apple Software. 
Neither the name, trademarks, service marks or 
logos of Apple Computer, Inc. may be used to 
endorse or promote products derived from the 
Apple Software without specific prior written 
permission from Apple.  Except as expressly 
stated in this notice, no other rights or 
licenses, express or implied, are granted by 
Apple herein, including but not limited to any 
patent rights that may be infringed by your 
derivative works or by other works in which the 
Apple Software may be incorporated.

The Apple Software is provided by Apple on an "AS 
IS" basis.  APPLE MAKES NO WARRANTIES, EXPRESS OR 
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED 
WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE, REGARDING 
THE APPLE SOFTWARE OR ITS USE AND OPERATION ALONE 
OR IN COMBINATION WITH YOUR PRODUCTS.

IN NO EVENT SHALL APPLE BE LIABLE FOR ANY 
SPECIAL, INDIRECT, INCIDENTAL OR CONSEQUENTIAL 
DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS 
OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) ARISING IN ANY WAY OUT OF THE USE, 
REPRODUCTION, MODIFICATION AND/OR DISTRIBUTION OF 
THE APPLE SOFTWARE, HOWEVER CAUSED AND WHETHER 
UNDER THEORY OF CONTRACT, TORT (INCLUDING 
NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN 
IF APPLE HAS BEEN ADVISED OF THE POSSIBILITY OF 
SUCH DAMAGE.

*/

#include "NaiveFormat.h"

// Utilities to free and allocate internal pixel buffers.
extern void 
freeInternalPixelBuffer( struct InternalPixelBuffer *buffer )
{
	int planeIndex;
	for( planeIndex = 0; planeIndex < 3; planeIndex++ ) {
		free( buffer->planeArray[planeIndex].planeBaseAddr );
		buffer->planeArray[planeIndex].planeBaseAddr = NULL;
	}
}

extern OSStatus 
callocInternalPixelBuffer( size_t width, size_t height, struct InternalPixelBuffer *buffer )
{
	size_t rowBytes;
	void *plane;
	freeInternalPixelBuffer( buffer );
	
	// Y plane is full-size.  
	rowBytes = (width + 15) & ~15;
	buffer->planeArray[0].planeRowBytes = rowBytes;
	
	plane = calloc( rowBytes * height, 1 );
	if( NULL == plane ) 
		return memFullErr;
	buffer->planeArray[0].planeBaseAddr = plane;
	
	// Cb and Cr planes are quarter-size.
	rowBytes = ((width/2) + 15) & ~15;
	buffer->planeArray[1].planeRowBytes = rowBytes;
	buffer->planeArray[2].planeRowBytes = rowBytes;
	
	plane = calloc( rowBytes * height / 2, 1 );
	if( NULL == plane ) 
		return memFullErr;
	buffer->planeArray[1].planeBaseAddr = plane;
	
	plane = calloc( rowBytes * height / 2, 1 );
	if( NULL == plane ) 
		return memFullErr;
	buffer->planeArray[2].planeBaseAddr = plane;
	
	return noErr;
}
