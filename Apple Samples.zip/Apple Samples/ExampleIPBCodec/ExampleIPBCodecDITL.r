// Set to 1 == building Mac OS X
#define TARGET_REZ_CARBON_MACHO 1

#if TARGET_REZ_CARBON_MACHO
    #include <Carbon/Carbon.r>
    #include <QuickTime/QuickTime.r>
#else
    #include "ConditionalMacros.r"
    #include "MacTypes.r"
    #include "Components.r"
    #include "ImageCodec.r"
#endif


#define kMyCodecDITLResID 129
#define kMyCodecPopupCNTLResID 129
#define kMyCodecPopupMENUResID 129

#define TEXT_HEIGHT 16
#define INTER_CONTROL_SPACING 12
#define POPUP_CONTROL_HEIGHT 22

resource 'DITL' (kMyCodecDITLResID, "Compressor Options") {
{
 {0, 0, TEXT_HEIGHT, 100},
 CheckBox { enabled, "Checkbox" },

 {TEXT_HEIGHT + INTER_CONTROL_SPACING, 0,
  TEXT_HEIGHT + INTER_CONTROL_SPACING + POPUP_CONTROL_HEIGHT, 165},
 Control { enabled, kMyCodecPopupCNTLResID },
 };
};

resource 'CNTL' (kMyCodecPopupCNTLResID, "Compressor Popup") {
 {0, 0, 20, 165},
 0,
 visible,
 60,        /* title width */
 kMyCodecPopupMENUResID,
 popupMenuCDEFProc+popupFixedWidth,
 0,
 "Menu:"
};

resource 'MENU' (kMyCodecPopupMENUResID, "Compressor Popup") {
 kMyCodecPopupMENUResID,
 textMenuProc,
 0x7FFD,       /* Enable flags */
 enabled,
 "Popup",
 { /* array: 8 elements */
  /* [1] */
  "Best", noIcon, noKey, noMark, plain,
  /* [2] */
  "-", noIcon, noKey, noMark, plain,
  /* [3] */
  "None", noIcon, noKey, noMark, plain,
  /* [4] */
  "Less", noIcon, noKey, noMark, plain,
  /* [5] */
  "Some", noIcon, noKey, noMark, plain,
  /* [6] */
  "More", noIcon, noKey, noMark, plain,
  /* [7] */
  "Many", noIcon, noKey, noMark, plain,
  /* [8] */
  "Most", noIcon, noKey, noMark, plain
 }
};