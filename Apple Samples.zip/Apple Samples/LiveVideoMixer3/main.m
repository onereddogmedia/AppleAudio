//
//  main.m
//  LiveVideoMixer
//
//  Created by Frank D�pke on Mon Jun 07 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    EnterMovies();
    return NSApplicationMain(argc, argv);
}
