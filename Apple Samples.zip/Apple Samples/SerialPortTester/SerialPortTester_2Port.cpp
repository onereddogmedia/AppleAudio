/*
 *  SerialPortTester_2Port.cpp
 *  SerialPortTester_2Port
 *
 *  Created by Peter Johnson on 31/05/07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include "SerialPortTester_2Port.h"

#include <iostream>
#include <cstdio>
#include <cassert>

#include <fcntl.h>
#include <sys/errno.h>
#include <sys/termios.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>

#include <sys/filio.h>
#include <sys/ioctl.h>
#include <CoreFoundation/CoreFoundation.h>

#include <IOKit/IOKitLib.h>
#include <IOKit/serial/IOSerialKeys.h>
#include <IOKit/IOBSD.h>

#include <pthread.h>


SerialPortTester_2Port::SerialPortTester_2Port(const std::string & master_port, const std::string &slave_port)
{
	// Open two serial ports for read/write
	// call them 'master' and 'slave' - purely arbitrary, could have chosen port A & B, or 1 & 2
	// using POSIX

	std::cout << "Open port \"" << master_port << "\"" << std::endl;

	//
	// Open and configure the master port 
	//

	master = open(master_port.c_str(), O_RDWR | O_NOCTTY | O_NDELAY);
	if (master == -1)
	{
		std::cerr << "open_port: Unable to open " << master_port << std::endl;
		assert(0);
	}
	else
	{
		std::cout << "master serial port open" << std::endl;
		fcntl(master, F_SETFL, 0);
	}

	// set master baud rate & control
	struct termios options;

	memset(&options, 0, sizeof(struct termios));

	cfmakeraw(&options);					// raw
    cfsetspeed(&options, B38400);			// set baud rate

	options.c_cflag |= CS8;					// 8bit
	options.c_cflag |= PARENB | PARODD;		// odd parity
	
    tcsetattr(master, TCSANOW, &options);	// set the new options


	// 
	// Open and configure the slave port
	//

	std::cout << "Open port \"" << slave_port << "\"" << std::endl;
	
	slave = open(slave_port.c_str(), O_RDWR | O_NOCTTY | O_NDELAY);
	if (slave == -1)
	{
		std::cerr << "open_port: Unable to open tty.USA28X2b2P2.2- " << std::endl;
		assert(0);
	}
	else
	{
		std::cout << "slave serial port open" << std::endl;
		fcntl(slave, F_SETFL, 0);
	}

	memset(&options, 0, sizeof(struct termios));

	cfmakeraw(&options);					// raw
    cfsetspeed(&options, B38400);			// set baud rate
	
	options.c_cflag |= CS8;					// 8bit
	options.c_cflag |= PARENB | PARODD;		// odd parity
	
    tcsetattr(slave, TCSANOW, &options);	// set the new options
	
	std::cout << "PASSED" << std::endl << std::endl;
}


SerialPortTester_2Port::~SerialPortTester_2Port()
{
	close(master);
	close(slave);
}


void SerialPortTester_2Port::Run()
{
	BasicTest1();
	BasicTest2();
}



//
// BasicTest1
// Test Details:
// Write a string of bytes from master to slave
// Read the string of bytes from master at slave

void SerialPortTester_2Port::BasicTest1()
{
	int nbytes = 0;
	const char * data = "hello";
	char buffer[255];

	std::cout << "BasicTest1" << std::endl;
	
	// TX master -> slave
	nbytes = write(master, data, strlen(data));
	if (nbytes < 0)
	{
		std::cout << "FAILED" << std::endl;
		assert(0);
	}
	
	// RX
	memset(buffer, 0, sizeof(buffer));
	nbytes = read(slave, buffer, strlen(data));
	if (nbytes < 0)
	{
		std::cout << "FAILED" << std::endl;
		assert(0);
	}
	
	// compare RX to TX
	if (strncmp(data, buffer, nbytes) == 0)
	{
		std::cout << "PASSED" << std::endl;
	}
	else
	{
		std::cout << "FAILED in compare" << std::endl;
		assert(0);
	}
	
	std::cout << "PASSED" << std::endl << std::endl;
}

//
// BasicTest2
// Test Details:
// Write a string of bytes from slave to master
// Read the string of bytes from slave at master

void SerialPortTester_2Port::BasicTest2()
{
	int nbytes = 0;
	const char * data = "hello";
	char buffer[255];

	std::cout << "BasicTest2" << std::endl;
	
	// TX slave -> master
	nbytes = write(slave, data, strlen(data));
	if (nbytes < 0)
	{
		std::cout << "FAILED" << std::endl;
		assert(0);
	}
	
	// RX
	memset(buffer, 0, sizeof(buffer));
	nbytes = read(master, buffer, strlen(data));
	if (nbytes < 0)
	{
		std::cout << "FAILED" << std::endl;
		assert(0);
	}
	
	// compare RX to TX
	if (strncmp(data, buffer, nbytes) == 0)
	{
		std::cout << "PASSED" << std::endl;
	}
	else
	{
		std::cout << "FAILED in compare" << std::endl;
		assert(0);
	}
	
	std::cout << "PASSED" << std::endl << std::endl;
}

