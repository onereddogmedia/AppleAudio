//
// Serial Port Tester
//	
// Use a suitable RS-422 cross-over cable to connect two serial ports together
//
// For reference with POSIX/BSD serial I/O: http://www.easysw.com/~mike/serial/serial.html


#include <iostream>
#include "SerialPortTester_2Port.h"
#include "SerialPortTester_Master.h"
#include "SerialPortTester_Slave.h"


int main (int argc, char * const argv[])
{
    std::cout << "Serial Port Tester!\n";

	if (argc < 2 || (argc == 3 && argv[2] == NULL) || (argc == 4 && argv[3] == NULL))
	{
		std::cout << "usage: SerialPortTester [-dual | -master | -slave] port {port}" << std::endl;
		exit(1);
	}

	std::string arg1 = std::string(argv[1]);
	std::string arg2 = std::string(argv[2]);
	std::string arg3;
	
	if (argc > 3)
	{
		arg3 = std::string(argv[3]);
	}

	if (arg1 == "-dual")
	{
		SerialPortTester_2Port tester(arg2, arg3);
		tester.Run();
	}
	else if (arg1 == "-master")
	{
		SerialPortTester_Master tester(arg2);
		tester.Run();
	}
	else if (arg1 == "-slave")
	{
		SerialPortTester_Slave tester(arg2);
		tester.Run();
	}

    return 0;
}
