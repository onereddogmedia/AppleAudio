/*
 *  SerialPortTester_Master.cpp
 *  SerialPortTester_Master
 *
 *  Created by Peter Johnson on 31/05/07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include "SerialPortTester_Master.h"

#include <iostream>
#include <cstdio>

#include <fcntl.h>
#include <sys/errno.h>
#include <sys/termios.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>

#include <sys/filio.h>
#include <sys/ioctl.h>
#include <CoreFoundation/CoreFoundation.h>

#include <IOKit/IOKitLib.h>
#include <IOKit/serial/IOSerialKeys.h>
#include <IOKit/IOBSD.h>

#include <pthread.h>


SerialPortTester_Master::SerialPortTester_Master(const std::string & master_port)
{
	// Open two serial ports for read/write
	// call them 'master' and 'slave' - purely arbitrary, could have chosen port A & B, or 1 & 2
	// using POSIX

	std::cout << "Open port \"" << master_port << "\"" << std::endl;

	//
	// Open and configure the master port 
	//

	master = open(master_port.c_str(), O_RDWR | O_NOCTTY | O_NDELAY);
	if (master == -1)
	{
		std::cerr << "open_port: Unable to open " << master_port << std::endl;
		assert(0);
	}
	else
	{
		std::cout << "master serial port open" << std::endl;
	}

	// set master baud rate & control
	struct termios options;

	memset(&options, 0, sizeof(struct termios));

	cfmakeraw(&options);					// raw
    cfsetspeed(&options, B38400);			// set baud rate

	options.c_cflag |= CS8;					// 8bit
	options.c_cflag |= PARENB | PARODD;		// odd parity
	
    tcsetattr(master, TCSANOW, &options);	// set the new options

	std::cout << "PASSED" << std::endl << std::endl;
}


SerialPortTester_Master::~SerialPortTester_Master()
{
	close(master);
}


void SerialPortTester_Master::Run()
{
	BasicTest1();
	sleep(2);
	BasicTest2();
}



//
// BasicTest1
// Test Details:
// Write a string of bytes from master to slave
// Read the string of bytes from master at slave

void SerialPortTester_Master::BasicTest1()
{
	int nbytes = 0;
	const char * data = "hello";

	std::cout << "BasicTest1" << std::endl;
	
	// TX master -> slave
	nbytes = write(master, data, strlen(data));
	if (nbytes < 0)
	{
		perror("write failure");
		std::cout << "FAILED" << std::endl;
		assert(0);
	}
	
	std::cout << "PASSED" << std::endl << std::endl;
}

//
// BasicTest2
// Test Details:
// Write a string of bytes from slave to master
// Read the string of bytes from slave at master

void SerialPortTester_Master::BasicTest2()
{
	int nbytes = 0;
	const char * data = "hello";
	char buffer[255];
	fd_set input, output, exception;
	struct timeval time;

	std::cout << "BasicTest2" << std::endl;

	FD_ZERO(&input);
	FD_SET(master, &input);
	FD_ZERO(&output);
	FD_SET(master, &output);
	FD_ZERO(&exception);
	FD_SET(master, &exception);
	memset(&time, 0, sizeof(struct timeval));
	time.tv_sec = 60;	// 60 second timeout

	int n = select(master + 1, &input, NULL, NULL, &time);

	if (n < 0)
	{
		perror("select failed");
		std::cout << "FAILED: " << __FILE__ << ":" << __LINE__ << std::endl;
		throw;
	}
	else if (n == 0)
	{
		std::cout << "TIMEOUT" << __FILE__ << ":" << __LINE__ << std::endl;
		throw;
	}
	else
	{
		if (FD_ISSET(master, &input))
		{
			// RX
			memset(buffer, 0, sizeof(buffer));
			char * bufptr = buffer;

			while ((nbytes = read(master, bufptr, buffer + strlen(data) - bufptr -1)) > 0)
			{
				bufptr += nbytes;
			}

			std::cout << nbytes << std::endl;
			
			if (nbytes < 0)
			{
				std::cout << "FAILED" << __FILE__ << ":" << __LINE__ << std::endl;
				throw;
			}
			
			// compare RX to TX
			if (strncmp(data, buffer, nbytes) == 0)
			{
				std::cout << "PASSED" << std::endl;
			}
			else
			{
				std::cout << "FAILED in compare" << __FILE__ << ":" << __LINE__ << std::endl;
				throw;
			}
			std::cout << "PASSED" << std::endl << std::endl;
		}
	}
}

