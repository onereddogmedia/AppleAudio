/*
 *  SerialPortTester_2Port.h
 *  SerialPortTester_2Port
 *
 *  Created by Peter Johnson on 31/05/07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include <string>

class SerialPortTester_Master
{
public:
	SerialPortTester_Master(const std::string & master_port);
	
	~SerialPortTester_Master();

	void Run();
	
	void BasicTest1();
	void BasicTest2();
	
	
private:
	int master;
};


