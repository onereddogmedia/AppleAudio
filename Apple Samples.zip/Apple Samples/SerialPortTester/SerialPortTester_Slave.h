/*
 *  SerialPortTester_Slave.h
 *  SerialPortTester_Slave
 *
 *  Created by Peter Johnson on 31/05/07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include <string>

class SerialPortTester_Slave
{
public:
	SerialPortTester_Slave(const std::string & slave_port);
	
	~SerialPortTester_Slave();

	void Run();
	
	void BasicTest1();
	void BasicTest2();
	
	
private:
	int slave;
};


