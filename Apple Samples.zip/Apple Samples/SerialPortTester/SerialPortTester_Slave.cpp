/*
 *  SerialPortTester_Slave.cpp
 *  SerialPortTester_Slave
 *
 *  Created by Peter Johnson on 31/05/07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include "SerialPortTester_Slave.h"

#include <iostream>
#include <cstdio>

#include <fcntl.h>
#include <sys/errno.h>
#include <sys/termios.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>

#include <sys/filio.h>
#include <sys/ioctl.h>
#include <CoreFoundation/CoreFoundation.h>

#include <IOKit/IOKitLib.h>
#include <IOKit/serial/IOSerialKeys.h>
#include <IOKit/IOBSD.h>

#include <pthread.h>


SerialPortTester_Slave::SerialPortTester_Slave(const std::string & slave_port)
{
	// Open two serial ports for read/write
	// call them 'master' and 'slave' - purely arbitrary, could have chosen port A & B, or 1 & 2
	// using POSIX

	// 
	// Open and configure the slave port
	//

	std::cout << "Open port \"" << slave_port << "\"" << std::endl;
	
	slave = open(slave_port.c_str(), O_RDWR | O_NOCTTY | O_NDELAY);
	if (slave == -1)
	{
		std::cerr << "open_port: Unable to open tty.USA28X2b2P2.2- " << __FILE__ << __LINE__ << std::endl;
		throw;
	}
	else
	{
		std::cout << "slave serial port open" << std::endl;
	}

	// set master baud rate & control
	struct termios options;

	memset(&options, 0, sizeof(struct termios));

	cfmakeraw(&options);					// raw
    cfsetspeed(&options, B38400);			// set baud rate
	
	options.c_cflag |= CS8;					// 8bit
	options.c_cflag |= PARENB | PARODD;		// odd parity
	
    tcsetattr(slave, TCSANOW, &options);	// set the new options
	
	std::cout << "PASSED" << std::endl << std::endl;
}


SerialPortTester_Slave::~SerialPortTester_Slave()
{
	close(slave);
}


void SerialPortTester_Slave::Run()
{
	BasicTest1();
	sleep(2);
	BasicTest2();
}



//
// BasicTest1
// Test Details:
// Write a string of bytes from master to slave
// Read the string of bytes from master at slave

void SerialPortTester_Slave::BasicTest1()
{
	int nbytes = 0;
	const char * data = "hello";
	char buffer[255];
	fd_set input, output, exception;
	struct timeval time;

	std::cout << "BasicTest1" << std::endl;

	FD_ZERO(&input);
	FD_SET(slave, &input);
	FD_ZERO(&output);
	FD_SET(slave, &output);
	FD_ZERO(&exception);
	FD_SET(slave, &exception);
	memset(&time, 0, sizeof(struct timeval));
	time.tv_sec = 10;	// 10 second timeout

	int n = select(slave + 1, &input, NULL, NULL, &time);

	if (n < 0)
	{
		perror("select failed");
		std::cout << "FAILED" << __FILE__ << __LINE__ << std::endl;
		throw;
	}
	else if (n == 0)
	{
		std::cout << "TIMEOUT" << __FILE__ << __LINE__ << std::endl;
		throw;
	}
	else
	{
		if (FD_ISSET(slave, &input))
		{
			// RX
			memset(buffer, 0, sizeof(buffer));
			nbytes = read(slave, buffer, strlen(data));
			if (nbytes < 0)
			{
				std::cout << "FAILED" << __FILE__ << __LINE__ << std::endl;
				throw;
			}
			
			// compare RX to TX
			if (strncmp(data, buffer, nbytes) == 0)
			{
				std::cout << "PASSED" << std::endl;
			}
			else
			{
				std::cout << "FAILED in compare" << __FILE__ << __LINE__ << std::endl;
				throw;
			}
		}
	}
}

//
// BasicTest2
// Test Details:
// Write a string of bytes from slave to master
// Read the string of bytes from slave at master

void SerialPortTester_Slave::BasicTest2()
{
	int nbytes = 0;
	const char * data = "hello";

	std::cout << "BasicTest2" << std::endl;
	
	// TX slave -> master
	while ((nbytes = write(slave, data, strlen(data))) < 0)
	{
	}

	std::cout << "PASSED" << std::endl;
}

