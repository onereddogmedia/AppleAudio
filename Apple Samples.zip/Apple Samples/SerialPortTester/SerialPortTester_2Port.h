/*
 *  SerialPortTester_2Port.h
 *  SerialPortTester_2Port
 *
 *  Created by Peter Johnson on 31/05/07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include <string>

class SerialPortTester_2Port
{
public:
	SerialPortTester_2Port(const std::string & master_port, const std::string & slave_port);
	
	~SerialPortTester_2Port();

	void Run();
	
	void BasicTest1();
	void BasicTest2();
	
	
private:
	int master;
	int slave;
};


